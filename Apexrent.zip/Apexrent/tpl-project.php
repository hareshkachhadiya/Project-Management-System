<?php
/* Template Name: Template: Apexrent Project */
?>
<?php get_header();?>
 <div class="main-wrapp">
        <section class="project-content">
            <div class="container">
                <div class="projct-desc mb-35">
                    <h1><?php the_field('projet_title'); ?></h1>
                </div>
                <div class="projct-gallery">
                    <h2><?php the_field('gallery_title'); ?></h2>
                    <div class="owl-carousel owl-theme gall-bw-after">
                    	<?php 
                        if( have_rows('slide_imags_list') ):
	                        while ( have_rows('slide_imags_list') ) : the_row();
                    		?>
                        <div class="item">
                            <div class="sl-item">
                                <img class="img-item" src="<?php echo get_sub_field('slide_image');?>" alt="">
                            </div>
                        </div>
                        <?php 
                    	endwhile;
                    	endif;
                    	?>
                    </div>
                </div>
                <div class="row mt-35">
                    <div class="col-md-6">
                        <div class="projct-before">
                            <h2>Before</h2>
                            <div class="owl-carousel owl-theme gall-bw-after">
                            	<?php 
                        		if( have_rows('slide_before_image_list') ):
	                        	while ( have_rows('slide_before_image_list') ) : the_row();
                    			?>
                                <div class="item">
                                    <div class="sl-item">
                                        <img class="img-item" src="<?php echo get_sub_field('slider_before_image');?>" alt="">
                                    </div>
                                </div>
          						<?php 
		                    	endwhile;
		                    	endif;
		                    	?>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="projct-after">
                            <h2>After</h2>
                            <div class="owl-carousel owl-theme gall-bw-after">
                            	<?php 
                        		if( have_rows('slider_after_image_list') ):
	                        	while ( have_rows('slider_after_image_list') ) : the_row();
                    			?>
                                <div class="item">
                                    <div class="sl-item">
                                        <img class="img-item" src="<?php echo get_sub_field('slider_after_image');?>" alt="">
                                    </div>
                                </div>
                                <?php 
		                    	endwhile;
		                    	endif;
		                    	?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- project Content end -->
        <section class="contact-note">
            <div class="container">
                <div class="text-left c-note s-note">
                    <h3><?php the_field('project_note'); ?></h3>
                </div>
            </div>
        </section>
        <!-- contact note end -->
    </div>
<?php get_footer(); ?>	