<?php
function apex_theme_customizer( $wp_customize ) {

	$wp_customize->add_panel('social_setting',array(
	    'title'=>'Social Setting',
	    'description'=> 'Social Settings',
	));

	/* Facebook Start */
	$wp_customize->add_section('facebook',array(
	    'title'=>'Facebook',
	    'panel'=>'social_setting',
	));

	$wp_customize->add_setting('fb_setting',array(
	    'defaule'=>'a',
	));

	$wp_customize->add_control('fb_link',array(
	    'label'=>'Link (URL)',
	    'description' => 'Enter the URL that you want to link the icon For example http://social-media-site.com/your-name/',
	    'type'=>'text',
	    'section'=>'facebook',
	    'settings'=>'fb_setting',
	));

	$wp_customize->add_setting('fb_setting_text',array(
	    'defaule'=>'a',
	));

	$wp_customize->add_control('fb_hover_text',array(
	    'label'=>'Hover Text',
	    'type'=>'text',
	    'section'=>'facebook',
	    'settings'=>'fb_setting_text',
	));
	/* Facebook End */

	/* book now start*/
	$wp_customize->add_section('Button_Name',array(
	    'title'=>'Button_Name',
	    'panel'=>'header_footer_settings',
	));

	$wp_customize->add_setting('button_settings',array(
	    'defaule'=>'a',
	));

	$wp_customize->add_control('button_link',array(
	    'label'=>'Link (URL)',
	    'description' => 'Enter the URL that you want to link the icon For example http://social-media-site.com/your-name/',
	    'type'=>'text',
	    'section'=>'Button_Name',
	    'settings'=>'button_settings',
	));

	$wp_customize->add_setting('button_setting_text',array(
	    'defaule'=>'a',
	));

	$wp_customize->add_control('btn_hover_text',array(
	    'label'=>'Hover Text',
	    'type'=>'dropdown-pages',
	    'section'=>'Button_Name',
	    'settings'=>'button_setting_text',
	));


	/* book now end*/


	/* Twitter Start */
	$wp_customize->add_section('twitter',array(
	    'title'=>'Twitter',
	    'panel'=>'social_setting',
	));
	$wp_customize->add_setting('tw_setting',array(
	    'defaule'=>'a',
	));

	$wp_customize->add_control('tw_link',array(
	    'label'=>'Link (URL)',
	    'description' => 'Enter the URL that you want to link the icon For example http://social-media-site.com/your-name/',
	    'type'=>'text',
	    'section'=>'twitter',
	    'settings'=>'tw_setting',
	));

	$wp_customize->add_setting('tw_setting_text',array(
	    'defaule'=>'a',
	));

	$wp_customize->add_control('tw_hover_text',array(
	    'label'=>'Hover Text',
	    'type'=>'text',
	    'section'=>'twitter',
	    'settings'=>'tw_setting_text',
	));
	/* Twitter End */

	/* Instagram Start */
	$wp_customize->add_section('instagram',array(
	    'title'=>'Instagram',
	    'panel'=>'social_setting',
	));

	$wp_customize->add_setting('in_setting',array(
	    'defaule'=>'a',
	));

	$wp_customize->add_control('in_link',array(
	    'label'=>'Link (URL)',
	    'description' => 'Enter the URL that you want to link the icon For example http://social-media-site.com/your-name/',
	    'type'=>'text',
	    'section'=>'instagram',
	    'settings'=>'in_setting',
	));

	$wp_customize->add_setting('in_setting_text',array(
	    'defaule'=>'a',
	));

	$wp_customize->add_control('in_hover_text',array(
	    'label'=>'Hover Text',
	    'type'=>'text',
	    'section'=>'instagram',
	    'settings'=>'in_setting_text',
	));
	/* Instagram End */

	/* Linkedin Start */
	$wp_customize->add_section('linkedin',array(
	    'title'=>'Linkedin',
	    'panel'=>'social_setting',
	));

	$wp_customize->add_setting('innk_setting',array(
	    'defaule'=>'a',
	));

	$wp_customize->add_control('innk_link',array(
	    'label'=>'Link (URL)',
	    'description' => 'Enter the URL that you want to link the icon For example http://social-media-site.com/your-name/',
	    'type'=>'text',
	    'section'=>'linkedin',
	    'settings'=>'innk_setting',
	));

	$wp_customize->add_setting('innk_setting_text',array(
	    'defaule'=>'a',
	));

	$wp_customize->add_control('innk_hover_text',array(
	    'label'=>'Hover Text',
	    'type'=>'text',
	    'section'=>'linkedin',
	    'settings'=>'innk_setting_text',
	));
	/* Linkedin End */

	/* Google+ Start */
	$wp_customize->add_section('googleplus',array(
	    'title'=>'Google +',
	    'panel'=>'social_setting',
	));

	$wp_customize->add_setting('gplus_setting',array(
	    'defaule'=>'a',
	));

	$wp_customize->add_control('gplus_link',array(
	    'label'=>'Link (URL)',
	    'description' => 'Enter the URL that you want to link the icon For example http://social-media-site.com/your-name/',
	    'type'=>'text',
	    'section'=>'googleplus',
	    'settings'=>'gplus_setting',
	));

	$wp_customize->add_setting('gplus_setting_text',array(
	    'defaule'=>'a',
	));

	$wp_customize->add_control('gplus_hover_text',array(
	    'label'=>'Hover Text',
	    'type'=>'text',
	    'section'=>'googleplus',
	    'settings'=>'gplus_setting_text',
	));
	/* Google+ End */

	/* YouTube Start */
	$wp_customize->add_section('youtube',array(
	    'title'=>'YouTube',
	    'panel'=>'social_setting',
	));

	$wp_customize->add_setting('yt_setting',array(
	    'defaule'=>'a',
	));

	$wp_customize->add_control('yt_link',array(
	    'label'=>'Link (URL)',
	    'description' => 'Enter the URL that you want to link the icon For example http://social-media-site.com/your-name/',
	    'type'=>'text',
	    'section'=>'youtube',
	    'settings'=>'yt_setting',
	));

	$wp_customize->add_setting('yt_setting_text',array(
	    'defaule'=>'a',
	));

	$wp_customize->add_control('yt_hover_text',array(
	    'label'=>'Hover Text',
	    'type'=>'text',
	    'section'=>'youtube',
	    'settings'=>'yt_setting_text',
	));
	/* YouTube End */

	/* Pinterest Start */
	$wp_customize->add_section('pinterest',array(
	    'title'=>'pinterest',
	    'panel'=>'social_setting',
	));

	$wp_customize->add_setting('pin_setting',array(
	    'defaule'=>'a',
	));

	$wp_customize->add_control('pin_link',array(
	    'label'=>'Link (URL)',
	    'description' => 'Enter the URL that you want to link the icon For example http://social-media-site.com/your-name/',
	    'type'=>'text',
	    'section'=>'pinterest',
	    'settings'=>'pin_setting',
	));

	$wp_customize->add_setting('pin_setting_text',array(
	    'defaule'=>'a',
	));

	$wp_customize->add_control('pin_hover_text',array(
	    'label'=>'Hover Text',
	    'type'=>'text',
	    'section'=>'pinterest',
	    'settings'=>'pin_setting_text',
	));
	/* Pinterest End */

	/* RSS Start */
	$wp_customize->add_section('rss',array(
	    'title'=>'RSS',
	    'panel'=>'social_setting',
	));

	$wp_customize->add_setting('rss_setting',array(
	    'defaule'=>'a',
	));

	$wp_customize->add_control('rss_link',array(
	    'label'=>'Link (URL)',
	    'description' => 'Enter a valid URL (http or https) to the RSS-feed. For example http://yourwebsite.com/feed/',
	    'type'=>'text',
	    'section'=>'rss',
	    'settings'=>'rss_setting',
	));

	$wp_customize->add_setting('rss_setting_text',array(
	    'defaule'=>'a',
	));

	$wp_customize->add_control('rss_hover_text',array(
	    'label'=>'Hover Text',
	    'type'=>'text',
	    'section'=>'rss',
	    'settings'=>'rss_setting_text',
	));
	/* RSS End */

	$wp_customize->add_panel( 'header_footer_settings', array(
		'capability'     => 'edit_theme_options',
		'theme_supports' => '',
		'title'          => __('Header & footer Settings', 'ecd'),
	) );

	/* phone entry start */
	$wp_customize->add_section('apex_top_bar_location_section', array(
		'title'      => __('Header settings', 'apex_top_bar_location_section'),
		'capability' => 'edit_theme_options',
		'panel'	=> 'header_footer_settings',
	));

	$wp_customize->add_setting('apex_location1_title',
		array(
			'type'              => 'theme_mod',
			'capability'        => 'edit_theme_options',
			'transport'         => 'refresh',
			//'sanitize_callback' => 'ecd_sanitize_url',
		)
	);

	$wp_customize->add_control('apex_location1_title', array(
		'type'     => 'url',
		'priority' => 200,
		'section'  => 'apex_top_bar_location_section',
		'label'    => __('Location', 'ecd'),
	));

	$wp_customize->add_setting('apex_location1_phone',
		array(
			'type'              => 'theme_mod',
			'capability'        => 'edit_theme_options',
			'transport'         => 'refresh',
			//'sanitize_callback' => 'ecd_sanitize_url',
		)
	);

	$wp_customize->add_control('apex_location1_phone', array(
		'type'     => 'url',
		'priority' => 200,
		'section'  => 'apex_top_bar_location_section',
		'label'    => __('Location  phone', 'ecd'),
	));


	$wp_customize->add_setting('apex_location2_title',
		array(
			'type'              => 'theme_mod',
			'capability'        => 'edit_theme_options',
			'transport'         => 'refresh',
			//'sanitize_callback' => 'ecd_sanitize_url',
		)
	);

	$wp_customize->add_control('apex_location2_title', array(
		'type'     => 'url',
		'priority' => 200,
		'section'  => 'apex_top_bar_location_section',
		'label'    => __('Location', 'ecd'),
	));

	$wp_customize->add_setting('apex_location2_phone',
		array(
			'type'              => 'theme_mod',
			'capability'        => 'edit_theme_options',
			'transport'         => 'refresh',
			//'sanitize_callback' => 'ecd_sanitize_url',
		)
	);

	$wp_customize->add_control('apex_location2_phone', array(
		'type'     => 'url',
		'priority' => 200,
		'section'  => 'apex_top_bar_location_section',
		'label'    => __('Location  phone', 'ecd'),
	));

	
	/* phone entry end */

	/* Email Entry Start*/

	$wp_customize->add_setting('apex_email_title',
		array(
			'type'              => 'theme_mod',
			'capability'        => 'edit_theme_options',
			'transport'         => 'refresh',
			//'sanitize_callback' => 'ecd_sanitize_url',
		)
	);

	$wp_customize->add_control('apex_email_title', array(
		'type'     => 'url',
		'priority' => 200,
		'section'  => 'apex_top_bar_location_section',
		'label'    => __('Email', 'ecd'),
	));

	/* Email Entry End*/


	/*header script code*/
	$wp_customize->add_setting('apex_header_js_code',
		array(
			'type'              => 'theme_mod',
			'capability'        => 'edit_theme_options',
			//'transport'         => 'refresh',
			//'sanitize_callback' => 'ecd_sanitize_url',
		)
	);

	$wp_customize->add_control('apex_header_js_code', array(
		'type'     => 'textarea',
		'priority' => 200,
		'section'  => 'apex_top_bar_location_section',
		'label'    => __('Header Javascript code', 'ecd'),
	));

	/* Location start */

	/*Footer Section start*/
	$wp_customize->add_section('apex_top_bar_section2', array(
		'title'      => __('Footer settings', 'apex_top_bar_section2'),
		'capability' => 'edit_theme_options',
		'panel'	=> 'header_footer_settings',
	));

	/*copyright text start*/
		$wp_customize->add_setting('apex_copyright',
			array(
				'type'              => 'theme_mod',
				'capability'        => 'edit_theme_options',
				'transport'         => 'refresh',
				//'sanitize_callback' => 'ecd_sanitize_url',
			)
		);

		$wp_customize->add_control('apex_copyright', array(
			'type'     => 'text',
			'priority' => 200,
			'section'  => 'apex_top_bar_section2',
			'label'    => __('Copyright Text', 'ecd'),
		));

	/*Footer Social text start*/
	$wp_customize->add_setting('apex_fotoersocialtext',
		array(
			'type'              => 'theme_mod',
			'capability'        => 'edit_theme_options',
			'transport'         => 'refresh',
			//'sanitize_callback' => 'ecd_sanitize_url',
		)
	);

	$wp_customize->add_control('apex_fotoersocialtext', array(
		'type'     => 'text',
		'priority' => 200,
		'section'  => 'apex_top_bar_section2',
		'label'    => __('Social Text', 'ecd'),
	));

    /*Footer script code*/
    $wp_customize->add_setting('apex_footer_js_code',
    	array(
    		'type'              => 'theme_mod',
    		'capability'        => 'edit_theme_options',
    	)
    );

    $wp_customize->add_control('apex_footer_js_code', array(
    	'type'     => 'textarea',
    	'priority' => 200,
    	'section'  => 'apex_top_bar_section2',
    	'label'    => __('Footer Javascript code', 'ecd'),
    ));
}
/* home extra end*/

function apex_sanitize_url( $url ) {
	return esc_url_raw( $url );
}
add_action( 'customize_register', 'apex_theme_customizer');
?>