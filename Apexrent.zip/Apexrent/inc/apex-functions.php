<?php

function apex_set_theme_var() {
	$theme_data = array(
		'fb_link'        			  => get_theme_mod('fb_setting'),
		'fb_hover_text'         	  => get_theme_mod('fb_setting_text'),
		'btn_link'        			  => get_theme_mod('button_settings'),
		'btn_hover_text'         	  => get_theme_mod('button_setting_text'),
		'tw_link'        			  => get_theme_mod('tw_setting'),
		'tw_hover_text'         	  => get_theme_mod('tw_setting_text'),
		'in_link'        			  => get_theme_mod('in_setting'),
		'in_hover_text'         	  => get_theme_mod('in_setting_text'),
		'innk_link'        			  => get_theme_mod('innk_setting'),
		'innk_hover_text'         	  => get_theme_mod('innk_setting_text'),
		'gplus_link'        		  => get_theme_mod('gplus_setting'),
		'gplus_hover_text'         	  => get_theme_mod('gplus_setting_text'),
		'yt_link'        			  => get_theme_mod('yt_setting'),
		'yt_hover_text'         	  => get_theme_mod('yt_setting_text'),
		'pin_link'        			  => get_theme_mod('pin_setting'),
		'pin_hover_text'         	  => get_theme_mod('pin_setting_text'),
		'rss_link'        			  => get_theme_mod('rss_setting'),
		'rss_hover_text'         	  => get_theme_mod('rss_setting_text'),
		'location_title'		  	  => get_theme_mod('apex_location1_title'),
		'location_phone'		  	  => get_theme_mod('apex_location1_phone'),
		'location_title2'		  	  => get_theme_mod('apex_location2_title'),
		'location_phone2'		  	  => get_theme_mod('apex_location2_phone'),
		'email'		  	  			  => get_theme_mod('apex_email_title'),
		'header_js_code'              => get_theme_mod('apex_header_js_code'),
		'footer_js_code'              => get_theme_mod('apex_footer_js_code'),
		'copyright'		  			  => get_theme_mod('apex_copyright'),
		'fotoersocialtext'		  	  => get_theme_mod('apex_fotoersocialtext'),
		'custom_logo_id'			  => get_theme_mod('custom_logo'),
	);
	return $theme_data;
}

function apex_get_social_block(){
    $theme_data = apex_set_theme_var();
    ?>
        <ul>
			<?php if($theme_data['fb_link']){?>
			<li><a target="_blank" href="<?php echo $theme_data['fb_link'];?>"><span class="ico"><i class="fab fa-facebook-f"></i></span><span><?php echo $theme_data['fb_hover_text'];?></span></a></li>
			<?php } ?>

			<?php if($theme_data['tw_link']){?>
			<li><a target="_blank" href="<?php echo $theme_data['tw_link'];?>"><span class="ico"><i class="fab fa-twitter"></i></span><span><?php echo $theme_data['tw_hover_text'];?></span></li>
			<?php } ?>

			<?php if($theme_data['in_link']){?>
			<li><a target="_blank" href="<?php echo $theme_data['in_link'];?>"><span class="ico"><i class="fab fa-instagram"></i></span><span><?php echo $theme_data['in_hover_text'];?></span></a></li>
			<?php } ?>

    		<?php if($theme_data['innk_link']){?>
    		<li><a target="_blank" href="<?php echo $theme_data['innk_link'];?>"><span class="ico"><i class="fab fa-linkedin-in"></i></span><span><?php echo $theme_data['innk_hover_text'];?></span></a></li>
    		<?php } ?>

    		<?php if($theme_data['gplus_link']){?>
    		<li><a target="_blank" href="<?php echo $theme_data['gplus_link'];?>"><span class="ico"><i class="fab fa-google-plus-g"></i></span><span><?php echo $theme_data['gplus_hover_text'];?></span></a></li>
    		<?php } ?>

    		<?php if($theme_data['yt_link']){?>
    		<li><a target="_blank" href="<?php echo $theme_data['yt_link'];?>"><span class="ico"><i class="fab fa-youtube"></i></span><span><?php echo $theme_data['yt_hover_text'];?></span></a></li>
    		<?php } ?>

    		<?php if($theme_data['pin_link']){?>
    		<li><a target="_blank" href="<?php echo $theme_data['pin_link'];?>"><span class="ico"><i class="fab fa-pinterest-p"></i></span><span><?php echo $theme_data['pin_hover_text'];?></span></a></li>
    		<?php } ?>

    		<?php if($theme_data['rss_link']){?>
    		<li><a target="_blank" href="<?php echo $theme_data['rss_link'];?>"><span class="ico"><i class="fab fa-rss"></i></span><span><?php echo $theme_data['rss_hover_text'];?></span></a></li>
    		<?php } ?>
		</ul>
    <?php
}

function apex_get_social_block_header(){
    $theme_data = apex_set_theme_var();
    ?>
			<?php if($theme_data['fb_link']){?>
			<a target="_blank" class="facebook" href="<?php echo $theme_data['fb_link'];?>"><i class="fab fa-facebook-f"></i></a>
			<?php } ?>

			<?php if($theme_data['tw_link']){?>
			<a target="_blank" class="twitter" href="<?php echo $theme_data['tw_link'];?>"><i class="fab fa-twitter"></i>
			<?php } ?>

			<?php if($theme_data['in_link']){?>
			<a target="_blank" href="<?php echo $theme_data['in_link'];?>"><i class="fab fa-instagram"></i></a>
			<?php } ?>

    		<?php if($theme_data['innk_link']){?>
    		<a target="_blank" href="<?php echo $theme_data['innk_link'];?>"><i class="fab fa-linkedin-in"></i></a>
    		<?php } ?>

    		<?php if($theme_data['gplus_link']){?>
    		<a target="_blank" href="<?php echo $theme_data['gplus_link'];?>"><i class="fab fa-google-plus-g"></i></a>
    		<?php } ?>

    		<?php if($theme_data['yt_link']){?>
    		<a target="_blank" class="youtube" href="<?php echo $theme_data['yt_link'];?>"><i class="fab fa-youtube"></i></a>
    		<?php } ?>

    		<?php if($theme_data['pin_link']){?>
    		<a target="_blank" href="<?php echo $theme_data['pin_link'];?>"><i class="fab fa-pinterest-p"></i></a>
    		<?php } ?>

    		<?php if($theme_data['rss_link']){?>
    		<a target="_blank" href="<?php echo $theme_data['rss_link'];?>"><i class="fab fa-rss"></i></a>
    		<?php } ?>
    <?php
}

function apex_get_custom_logo(){
	$theme_data = apex_set_theme_var();
	$logo = wp_get_attachment_image_src( $theme_data['custom_logo_id'] , 'full' );
	if ( has_custom_logo() ) {
        echo '<img src="'. esc_url( $logo[0] ) .'" class="img-responsive">';
	} else {
        echo '<h1>'. get_bloginfo( 'name' ) .'</h1>';
	}
}

function apex_get_footer_logo(){
	$theme_data = apex_set_theme_var_set_theme_var();
	$logo = wp_get_attachment_image_src( $theme_data['custom_logo_id'] , 'full' );
	list($width, $height, $type, $attr) = getimagesize($logo[0]);
	if ( has_custom_logo() )
		echo '<a href="'.home_url().'"><img class="logo img-responsive" src="'. esc_url( $logo[0] ) .'" style="max-width:'.$width.'px;max-height:'.$height.'px;"></a>';
	else
		echo '<a href="#pagellh"><h1>'. get_bloginfo( 'name' ) .'</h1></a>';
}
?>