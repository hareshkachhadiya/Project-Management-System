 <!-- footer main end -->
 <?php wp_footer(); ?>
 <footer class="footer">
        <div class="footer-main">
            <div class="container">
                <div class="row">
                    <div class="col-md-4">
                        <div class="foot-part">
                            <div class="foot-title">
                                <strong>Browse </strong> Our Website
                            </div>
                            <div class="foot-main">
                                    <?php dynamic_sidebar( 'custom-header-widget-menu' ); ?>     
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="foot-part">
                            <div class="foot-title">
                                <strong>Contact </strong> Information
                            </div>
                            <div class="foot-main">
                            	<?php dynamic_sidebar('custom-header-widget'); ?> 
                                <div class="social-foot">
                                     <?php apex_get_social_block_header(); ?>
                                </div>
                                <div class="pay-option">
                                    <?php dynamic_sidebar('custom-header-widget-payment');?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="foot-part">
                            <div class="foot-title">
                                <strong>Contact </strong> Form
                            </div>
                            <div class="foot-main">
                                <?php dynamic_sidebar('custom-header-widget-form');?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-copyright">
            <div class="container">
                <div class="copy-right text-center">
                    <?php $theme_data = apex_set_theme_var();
                    echo $theme_data['copyright'];
                    ?>
                </div>
            </div>
        </div>
        <!-- Footer Copyright end -->
    </footer>
    <!-- Footer end -->
<?php 
        echo $theme_data['footer_js_code'];
        wp_footer();
    ?>