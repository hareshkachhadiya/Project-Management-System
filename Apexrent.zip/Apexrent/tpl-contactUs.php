<?php
/* Template Name: Template: Apexrent Contact Us */
?>
<?php get_header();?>

 <div class="main-wrapp">
        <section class="contact-content">
            <div class="container">
                <div class="contact-desc">
                    <h1><?php the_field('contact_title'); ?></h1>
                    <h2 class="mt-4"><?php the_field('contact_us'); ?></h2>
                    <p><?php the_field('contact_description'); ?></p>
                    <div class="row mt-40">
                        <div class="col-md-6">
                            <div class="contact-form">
                                <?php
                                // TO SHOW THE PAGE CONTENTS
                                while ( have_posts() ) : the_post(); ?>
                                        <?php the_content(); ?>
                                <?php
                                endwhile; 
                                wp_reset_query(); //resetting the page query
                                ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <?php the_field('contact_detail'); ?>
                            <div class="pay-option">
                                <p><strong><?php the_field('payment_option'); ?></strong></p>
                                <span><?php dynamic_sidebar('custom-header-widget-payment'); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- About Content end -->
        <section class="contact-note">
            <div class="container">
                <div class="text-left c-note s-note">
                    <h3><?php the_field('contact_note'); ?></h3>
                </div>
            </div>
        </section>
        <!-- contact note end -->
    </div>
<?php get_footer(); ?>	