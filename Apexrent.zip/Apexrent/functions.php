<?php
function apex_enqueue_styles() {
    wp_register_style('font-link', 'https://fonts.googleapis.com/css?family=Abel|Fira+Sans:100,200,300,400,400i,500,600,700,800,900|Quattrocento+Sans:400,400i,700,700i' );
    wp_enqueue_style('font-link');

    wp_register_style('bootstrap', get_template_directory_uri() . '/css/bootstrap.min.css' );
    wp_enqueue_style('bootstrap');

   /*wp_register_style('animate', get_template_directory_uri() . '/css/animate.css' );
    wp_enqueue_style('animate');*/

    wp_register_style('fontawesome', get_template_directory_uri() . '/fontawesome/css/all.css' );
    wp_enqueue_style('fontawesome');

	wp_register_style('owl.carousel', get_template_directory_uri() . '/css/owl.carousel.min.css' );
    wp_enqueue_style('owl.carousel');

    /*wp_register_style('owl.theme', get_template_directory_uri() . '/css/owl.theme.default.min.css' );
    wp_enqueue_style('owl.theme');

    wp_register_style('pogo-slider.min', get_template_directory_uri() . '/css/pogo-slider.min.css' );
    wp_enqueue_style('pogo-slider.min');*/

    wp_register_style('style', get_template_directory_uri() . '/css/style.css' );
    wp_enqueue_style('style');

    wp_register_style('responsive', get_template_directory_uri() . '/css/responsive.css' );
    wp_enqueue_style('responsive');

     wp_register_style('custom', get_template_directory_uri() . '/css/custom.css' );
    wp_enqueue_style('custom');
}

function apex_enqueue_scripts() {
    wp_register_script('jquery', get_template_directory_uri() . '/js/jquery-3.3.1.slim.min.js' ,'','',true);
    wp_enqueue_script('jquery');

    /*wp_register_script('jquery-ui', get_template_directory_uri() . '/js/jquery-ui.min.js' ,'','',true);
    wp_enqueue_script('jquery-ui');*/
    wp_register_script('bootstrap', get_template_directory_uri() . '/js/bootstrap.min.js' ,'','',true);
    wp_enqueue_script('bootstrap');

    wp_register_script('popper', get_template_directory_uri() . '/js/popper.min.js' ,'','',true);
    wp_enqueue_script('popper');

    wp_register_script('owl-carousel', get_template_directory_uri() . '/js/owl.carousel.min.js' ,'','',true);
    wp_enqueue_script('owl-carousel');

    wp_register_script('fontawesome', get_template_directory_uri() . '/fontawesome/js/all.js' ,'','',true);
    wp_enqueue_script('fontawesome');

    wp_register_script('livesite', get_template_directory_uri() . '/js/livesite.js' ,'','',true);
    wp_enqueue_script('livesite');

    wp_register_script('all', get_template_directory_uri() . '/js/all.js' ,'','',true);
    wp_enqueue_script('all');

    wp_register_script('custom', get_template_directory_uri() . '/js/custom.js' ,'','',true);
    wp_enqueue_script('custom');
}

add_action( 'wp_enqueue_scripts', 'apex_enqueue_styles' );
add_action( 'wp_enqueue_scripts', 'apex_enqueue_scripts' );

require get_template_directory() . '/inc/apex-functions.php';
require get_template_directory() . '/inc/apex-customizer.php';

add_theme_support('post-thumbnails');
add_theme_support( 'widgets');
add_theme_support( 'title-tag' );
add_theme_support('menus');
add_theme_support( 'custom-logo');

    
// for menu add

function add_specific_menu_location_atts( $atts, $item, $args ) { 
// check if the item is in the primary menu 
	if( $args->theme_location == 'header-menu' ) { 
	// add the desired attributes: 
		$atts['class'] = 'nav-link'; 
	} 
	return $atts; 
} 
add_filter( 'nav_menu_link_attributes', 'add_specific_menu_location_atts', 10, 3 );


function special_nav_class($classes, $item){
    if( in_array('current-menu-item', $classes) ){
        $classes[] = 'active';
    }
    return $classes;
}
add_filter('nav_menu_css_class' , 'special_nav_class' , 10 , 2);

function create_posttype() {
 
    register_post_type( 'destination',
    // CPT Options
        array(
            'labels' => array(
                'name' => __( 'Destination' ),
                'singular_name' => __( 'Destination' )
            ),
            'public' => true,
            'has_archive' => true,
            'rewrite' => array('slug' => 'destination'),
        )
    );
}
// Hooking up our function to theme setup
add_action( 'init', 'create_posttype' );


//for featured image in destination
 register_post_type('destination', array(
            'labels' => array(
                'name' => __('Companies'),
                'singular_name' => __('Company')
            ),
            'public' => true,
            'has_archive' => true,
            'supports' => array('thumbnail', 'title', 'editor')
                )
        );

function wpb_widgets_init() {
 
    register_sidebar( array(
        'name'          => 'Footer widget',
        'id'            => 'custom-header-widget',
        'before_widget' => '<div class="chw-widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<h2 class="chw-title">',
        'after_title'   => '</h2>',
    ) );
 
}
add_action( 'widgets_init', 'wpb_widgets_init' );


function wpb_widgets_menu() {
 
    register_sidebar( array(
        'name'          => 'Footer widget Menu',
        'id'            => 'custom-header-widget-menu',
        'before_widget' => '<div class="chw-widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<h2 class="chw-title">',
        'after_title'   => '</h2>',
    ) );
 
}
add_action( 'widgets_init', 'wpb_widgets_menu' );

function wpb_widgets_payment() {
 
    register_sidebar( array(
        'name'          => 'Footer Payment widget',
        'id'            => 'custom-header-widget-payment',
        'before_widget' => '<span>',
        'after_widget'  => '</span>',
        'before_title'  => '<h2 class="chw-title">',
        'after_title'   => '</h2>',
    ) );
 
}
add_action( 'widgets_init','wpb_widgets_payment');

function wpb_widgets_form() {
 
    register_sidebar( array(
        'name'          => 'Footer Form widget',
        'id'            => 'custom-header-widget-form',
        'before_widget' => '<span>',
        'after_widget'  => '</span>',
        'before_title'  => '<h2 class="chw-title">',
        'after_title'   => '</h2>',
    ) );
 
}
add_action( 'widgets_init','wpb_widgets_form');

?>




