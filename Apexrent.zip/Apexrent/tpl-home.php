<?php
/* Template Name: Template: Apexrent Home */
?>
<?php get_header();?>
<div class="main-wrapp">
        <section class="slider">
            <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <?php
                                echo do_shortcode('[smartslider3 slider=1]');
                        ?>
                        <div class="carousel-caption d-none d-md-block">
                            <h3><?php the_field('slider_title'); ?></h3>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- slider end -->
        <section class="welcome-box">
            <div class="container">
                <div class="wel-box">
                    <div class="row">
                        <div class="col-md-7">
                            <div class="wel-desc">
                                <h3><?php the_field('welcome_title'); ?></h3>
                                <h2><?php the_field('welcome_tag'); ?></h2>
                                <p><?php the_field('welcome_description'); ?></p>
                            </div>
                        </div>
                        <div class="col-md-5">
                            <div class="wel-view">
                                <img class="img-fluid" src="<?php the_field('welcome') ?>"
                                    alt="Commercial Roofing — Roofing Contractors in Santa Clarita, CA">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Welcomr box end -->
        <section class="service-box">
            <div class="container">
                <div class="row">
                	<?php 
                        if( have_rows('services_list') ):
                        while ( have_rows('services_list') ) : the_row();
                    	?>
                    <div class="col-md-3 col-sm-6">
                        <div class="ser-box">
                            <div class="ser-view">
                                <a href="<?php echo get_sub_field('services_link'); ?>">
                                    <img class="img-fluid" src="<?php echo get_sub_field('services_images');?>" alt="Services">
                                </a>
                            </div>
                            <div class="ser-hed text-center">
                                <h5><?php echo get_sub_field('services_title');?></h5>
                            </div>
                        </div>    
                    </div>
                    <?php 
	                    endwhile;
	                    endif;
                    ?>
                </div>
            </div>
        </section>
        <!-- Service box end -->
        <section class="choose-option">
            <div class="container">
                <div class="roof-option">
                    <h2><?php the_field('option_title'); ?></h2>
                    <ul>
                    	<?php 
                        if( have_rows('roofing_options') ):
                        while ( have_rows('roofing_options') ) : the_row();
                    	?>
                        <li><?php echo get_sub_field('roofing_list');?></li>
                        <?php 
	                    endwhile;
	                    endif;
                    ?>
                    </ul>
                </div>
                <div class="why-us">
                    <h2><?php the_field('why_choose_us'); ?></h2>
                    <ul>
                    	<?php 
                        if( have_rows('why_choose_us_menu') ):
                        while ( have_rows('why_choose_us_menu') ) : the_row();
                    	?>
                        <li><?php echo get_sub_field('why_choose_us_list');?></li>
                        <?php 
	                    endwhile;
	                    endif;
	                    ?>
                    </ul>
                </div>
                <div class="youtube-video">
                    <a href="<?php the_field('youtube_link'); ?>" id="1681363756"
                        dm_dont_rewrite_url="false" file="false" class="" target="_blank">
                        <img src="<?php the_field('youtube');?>" id="1924888555" class=""
                            data-dm-image-path="images/youtube-icon.jpg" onerror="handleImageLoadError(this)">
                    </a>
                </div>
            </div>
        </section>
        <!-- Choose option end -->
        <section class="partner-box">
            <div class="container">
                <div class="row">
                	<?php 
                        if( have_rows('brand_list') ):
                        while ( have_rows('brand_list') ) : the_row();
                    	?>
                    <div class="col-md-25 col-sm-6 first-pb-col">
                        <div class="p-item">
                            <img class="img-fluid" src="<?php echo get_sub_field('brand_images');?>" alt="GAF">
                        </div>
                    </div>
                    <?php 
	                    endwhile;
	                    endif;
                    ?>
                </div>
            </div>
        </section>
        <!-- partner box end -->
        <section class="contact-note">
            <div class="container">
                <div class="text-left c-note">
                    <p><?php the_field('container_note'); ?></p>
                </div>
            </div>
        </section>
        <!-- contact note end -->
    </div>
    <!-- main wrapp end -->
<?php get_footer(); ?>