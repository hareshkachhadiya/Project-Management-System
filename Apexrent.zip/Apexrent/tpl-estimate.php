<?php
/* Template Name: Template: Apexrent Estimate */
?>
<?php get_header();?>
 <div class="main-wrapp">
        <section class="esti-content">
            <div class="container">
                <div class="est-desc">
                    <h1><?php the_field('estimate_title'); ?></h1>
                    <h2 class="mt-4"><?php the_field('estimate_description'); ?></h2>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="estimate-form">
                                <?php
                                // TO SHOW THE PAGE CONTENTS
                                while ( have_posts() ) : the_post(); ?>
                                        <?php the_content(); ?>
                                <?php
                                endwhile; 
                                wp_reset_query(); //resetting the page query
                                ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="estimate-img">
                                <img class="img-fluid" src="<?php the_field('estimate_image'); ?>" alt="Contractor on the Roof — Roof Repairs in Santa Clarita, CA">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- About Content end -->
        <section class="contact-note">
            <div class="container">
                <div class="text-left c-note s-note">
                    <h3><?php the_field('estimate_note'); ?></h3>
                </div>
            </div>
        </section>
        <!-- contact note end -->
    </div>
<?php get_footer(); ?>	