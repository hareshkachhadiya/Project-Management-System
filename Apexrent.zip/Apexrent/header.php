<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script type="text/javascript">
        var templateUrl = '<?= get_bloginfo("template_url"); ?>';
    </script>

    <?php 
	$theme_data = apex_set_theme_var();
	$logo = wp_get_attachment_image_src( $theme_data['custom_logo_id'] , 'full' );
    ?>
    <?php wp_head();?>
    <?php echo "\n".$theme_data['header_js_code']; ?>

</head>
<body <?php body_class(); ?>>
    <header class="">
        <nav class="navbar navbar-top">
            <div class="container">
                <d  iv class="row w-lg-100">
                    <div class="col-md-6 nbm-center">
                        <a class="navbar-brand" href="<?php echo home_url(); ?>">
                            <img src="<?php echo $logo[0];?>"
                                alt="Roofing Company - Santa Clarita, CA – Apex Enterprise Roofing, Inc.">
                        </a>
                    </div>
                    <div class="col-md-6 text-right">
                        <div class="socialmedia">
                            <!-- <a class="facebook" href="#">
                                <i class="fab fa-facebook-f"></i>
                            </a>
                            <a class="twitter" href="#">
                                <i class="fab fa-twitter"></i>
                            </a>
                            <a class="youtube" href="#">
                                <i class="fab fa-youtube"></i>
                            </a> -->
                            <?php apex_get_social_block_header(); ?>
                        </div>
                        <div class="call-today">
                            <span><?php echo $theme_data['location_title'];?></span><a href="tel:<?php echo $theme_data['location_phone'];?>"><?php echo $theme_data['location_phone'];?></a>
                        </div>
                        <div class="call-free">
                            <span><?php echo $theme_data['location_title2'];?></span><a href="tel:<?php echo $theme_data['location_phone2'];?>"><?php echo $theme_data['location_phone2'];?></a>
                        </div>
                        <div class="call-email"><a href="mailto:<?php echo $theme_data['email'];?>"><?php echo $theme_data['email'];?></a>
                        </div>
                        
                    </div>
                </div>
            </div>
        </nav>
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <div class="container">
                <button class="navbar-toggler" type="button" data-toggle="collapse"
                    data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <?php
                           // Menu Location
                           wp_nav_menu( array(
                            'menu'              => 'header menu',
                            'theme_location'    => 'header-menu',
                            'depth'             => 0,
                            'container'         => 'ul',
                            'menu_class'        => 'navbar-nav mr-auto',
                            'item_spacing'		=>'preserve',
                            )
                            );
                       ?>
                </div>
            </div>
        </nav>
    </header>
    <!-- header end -->