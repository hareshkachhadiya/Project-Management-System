<?php
/* Template Name: Template: Apexrent Services
 */
?>
<?php get_header();?>
 <div class="main-wrapp">
        <section class="ser-content">
            <div class="container">
                <div class="ser-desc">
                    <h1>
                       <?php the_field('services_title'); ?>
                    </h1>
                    <div class="row mt-2">
                        <div class="col-md-7">
                            <div class="serd-text">
                                <h2> <?php the_field('services'); ?></h2>
                                <h3> <?php the_field('services_hour'); ?></h3>
                                <p> <?php the_field('services_description'); ?></p>
                            </div>
                        </div>
                        <div class="col-md-5">
                            <div class="serd-img">
                                <img class="img-fluid" src=" <?php the_field('services_image'); ?>"
                                    alt="Man Drilling Roofs — Home Roofing in Santa Clarita, CA">
                            </div>
                        </div>
                    </div>
                </div>
                <hr class="mb-35 mt-40">
                <div class="ser-systm">
                    <h4><?php the_field('steep_slope_systems'); ?></h4>
                    <p><?php the_field('steep_slope_systems_description'); ?></p>
                    <div class="systm-ul mb-35">
                        <ul class="col-m3">
                        	<?php 
	                        if( have_rows('slop_system_material') ):
	                        while ( have_rows('slop_system_material') ) : the_row();
	                    	?>
                            <li><?php echo get_sub_field('slop_system_material_list');?></li>
                        <?php 
	                    endwhile;
	                    endif;
                    	?>
                        </ul>
                    </div>
                    <p><?php the_field('slop_system_material_description'); ?></p>
                </div>
                <?php 
                if( have_rows('services_system') ):
                while ( have_rows('services_system') ) : the_row();
            	?>
                <hr class="mb-35 mt-40">
                <div class="ser-systm">
                    <h4><?php echo get_sub_field('service_system_title');?></h4>
                    <p><?php echo get_sub_field('service_system_description');?></p>
                </div>
                <?php 
                endwhile;
                endif;
            	?>
                <hr class="mb-35 mt-40">
                <div class="ser-systm">
                    <div class="row">
                        <div class="col-md-7">
                            <h4><?php the_field('roof_maintenance'); ?></h4>
                            <p><?php the_field('roof_maintenance_description'); ?></p>
                        </div>
                        <div class="col-md-5">
                            <div class="serd-img mt-0">
                                <img class="img-fluid" src="<?php the_field('roof_maintenance_image'); ?>"
                                    alt="Man Drilling Roofs — Home Roofing in Santa Clarita, CA">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="ser-systm pt-5">
                    <p><?php the_field('maintenance_inspections'); ?></p>
                </div>
            </div>
        </section>
        <!-- About Content end -->
        <section class="contact-note">
            <div class="container">
                <div class="text-left c-note s-note">
                    <h2><?php the_field('service_note_title'); ?></h2>
                    <p class="mb-4"><?php the_field('service_note_description'); ?></p>
                    <h3><?php the_field('more_information'); ?></h3>
                </div>
            </div>
        </section>
        <!-- contact note end -->
    </div>
<?php get_footer(); ?>