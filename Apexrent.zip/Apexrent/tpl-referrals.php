<?php
/* Template Name: Template: Apexrent Referrals */
?>
<?php get_header();?>
 <div class="main-wrapp">
        <section class="ser-content">
            <div class="container">
                <div class="ref-desc">
                    <h1><?php the_field('referrals_title'); ?></h1>
                    <p><?php the_field('referrals_description'); ?></p>
                    <?php 
            		if( have_rows('restaurants_to_choose_from') ):
                	while ( have_rows('restaurants_to_choose_from') ) : the_row();
        			?>
                    <div class="ref-ul mt-40">
                        <h3><?php echo get_sub_field('choose_from_title');?></h3>
                        <div class="row">
                        	<?php 
		            		if( have_rows('choose_from_item_list') ):
		                	while ( have_rows('choose_from_item_list') ) : the_row();
		        			?>
                            <div class="col-md-4">
                            	<ul>
                            	<?php 
			            		if( have_rows('choose_from_item_option') ):
			                	while ( have_rows('choose_from_item_option') ) : the_row();
			        			?>
			        				<li><?php echo get_sub_field('choose_from_items'); ?></li>
                                
                                <?php 
			                	endwhile;
			                	endif;
			                	?>
			                	</ul>
                            </div>
                            <?php 
		                	endwhile;
		                	endif;
		                	?>
                        </div>
                    </div>
                    <?php 
                	endwhile;
                	endif;
                	?>
                    <div class="mt-35">
                        <p><strong><?php the_field('check_murchent'); ?></strong></p>
                        <div class="restro-murchant">
                        	<?php 
		            		if( have_rows('restaurants_and_merchants_list') ):
		                	while ( have_rows('restaurants_and_merchants_list') ) : the_row();
		        			?>
                            <img class="img-fluid" src="<?php echo get_sub_field('restaurants_and_merchants_brand'); ?>" alt="Albertsons">
                            <?php 
		                	endwhile;
		                	endif;
		                	?>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- About Content end -->
        <section class="contact-note">
            <div class="container">
                <div class="text-left c-note s-note">
                    <h3><?php the_field('referrals_note'); ?></h3>
                </div>
            </div>
        </section>
        <!-- contact note end -->
    </div>
<?php get_footer(); ?>	