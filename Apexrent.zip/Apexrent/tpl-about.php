<?php
/* Template Name: Template: Apexrent About */
?>
<?php get_header();?>
 <div class="main-wrapp">
        <section class="ab-content">
            <div class="container">
                <div class="ab-desc">
                    <h1><?php the_field('about_title'); ?></h1>
                    <div class="row mt-30">
                        <div class="col-md-7">
                            <div class="abd-text">
                                <h2><?php the_field('about'); ?></h2>
                                <p><?php the_field('about_description'); ?></p>
                            </div>
                        </div>
                        <div class="col-md-5">
                            <div class="abd-img">
                                <img class="img-fluid" src="<?php the_field('about_image');?>"
                                    alt="Residential Roofing — Professional Roofing in Santa Clarita, CA">
                            </div>
                        </div>
                    </div>
                    <div class="abd-text mt-30">
                        <p><?php the_field('about_detail'); ?></p>
                    </div>
                </div>
            </div>
        </section>
        <!-- About Content end -->
        <section class="contact-note">
            <div class="container">
                <div class="text-left c-note">
                    <h3><?php the_field('about_note'); ?></h3>
                    <h3><?php the_field('about_note_description'); ?></h3>
                </div>
            </div>
        </section>
        <!-- contact note end -->
    </div>
<?php get_footer(); ?>